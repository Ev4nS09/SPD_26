package ethernet;

import java.util.Arrays;

// class that implements a device
public class Device implements Port {
	private MacAddress mac; // the MAC address
	private String id; // the id of the device, it must be unique
	private final Switch parent; // the switch this device is attached to
	
	
	public Device(String id, MacAddress mac, Switch parent) {
		if (id == null || mac == null || parent == null)
            throw new NullPointerException();
		this.id = id;
		this.mac = mac;
		this.parent = parent;
	}
	
	// the switch sends a frame to this device
	// in case of broadcasting, the device uses method 'receive' of its parent
	// to communicate its MAC address
	@Override
    public void send(EthernetFrame frame) {
        if (Prelude.BROADCAST_ADDR.equals(frame.getDestination())) {
            byte[] payload = "Reply from device".getBytes();
            if (payload.length < Prelude.MIN_PAYLOAD_LEN) {
                payload = Arrays.copyOf(payload, Prelude.MIN_PAYLOAD_LEN);
            }

            EthernetFrame reply = new EthernetFrame(
                frame.getSource().getBytes(), // destination
                mac.getBytes(),               // this device’s MAC as source
                (short)0x0800,
                payload
            );
            parent.receive(reply, this);
        }
    }

	// getters

	public MacAddress get_Mac() {
		return mac;
	}

	public Switch get_Parent() {
		return parent;
	}

	public String get_Id() {
		return id;
	}
	

	// setters

	public void set_Id(String id) {
		if (id == null)
            throw new NullPointerException();
		this.id = id;
	}
}
