package ethernet;

import java.util.Arrays;


// implementation of an Ethernet frame
// CRC is not encoded by the frame.
public class EthernetFrame {
    private MacAddress destination;
    private MacAddress source;
    private short etherType;
    private byte[] payload; // data + padding

    // Construct from fields
    public EthernetFrame(byte[] destination, byte[] source, short etherType, byte[] payload) {
    	if (destination == null || source == null || payload == null)
            throw new NullPointerException();
    	
        if (destination.length != Prelude.MAC_ADDR_LEN || source.length != Prelude.MAC_ADDR_LEN) {
            throw new IllegalArgumentException("MAC addresses must be 6 bytes");
        }
        
        if (payload.length > Prelude.MAX_PAYLOAD_LEN) {
            throw new IllegalArgumentException("Payload too large (max " + Prelude.MAX_PAYLOAD_LEN + ")");
        }

        this.destination = new MacAddress(destination);
        this.source = new MacAddress(source);
        this.etherType = etherType;
        this.payload = Arrays.copyOf(payload, payload.length);
    }
    
    // Construct from raw bytes: header + payload
    public EthernetFrame(byte[] raw) {

    	if (raw == null)
            throw new NullPointerException();
    	
        if (raw.length < Prelude.HEADER_LEN + Prelude.MIN_PAYLOAD_LEN) {
            throw new IllegalArgumentException("Frame too short");
        }
        
        int payloadLen = raw.length - Prelude.HEADER_LEN;
        if (payloadLen > Prelude.MAX_PAYLOAD_LEN) {
            throw new IllegalArgumentException("Payload too large (max " + Prelude.MAX_PAYLOAD_LEN + ")");
        }

        // first 6 bytes = destination MAC
        this.destination = new MacAddress(Arrays.copyOfRange(raw, 0, Prelude.MAC_ADDR_LEN));

        // next 6 bytes = source MAC
        this.source = new MacAddress(Arrays.copyOfRange(raw,
                                                        Prelude.MAC_ADDR_LEN,
                                                        2 * Prelude.MAC_ADDR_LEN));

        // EtherType is 2 bytes big-endian
        this.etherType = (short) (((raw[12] & 0xFF) << 8) | (raw[13] & 0xFF));

        // everything after the header is payload (includes padding if present)
        this.payload = Arrays.copyOfRange(raw, Prelude.HEADER_LEN, raw.length);
    }

    // Serialize to bytes (payload to 46 bytes if shorter)
    public byte[] toBytes() {
        int payloadLen = Math.max(payload.length, Prelude.MIN_PAYLOAD_LEN);
        byte[] out = new byte[Prelude.HEADER_LEN + payloadLen];

        byte[] dst = destination.getBytes();
        byte[] src = source.getBytes();

        System.arraycopy(dst, 0, out, 0, Prelude.MAC_ADDR_LEN);
        System.arraycopy(src, 0, out, Prelude.MAC_ADDR_LEN, Prelude.MAC_ADDR_LEN);

        out[12] = (byte) ((etherType >>> 8) & 0xFF);
        out[13] = (byte) (etherType & 0xFF);

        System.arraycopy(payload, 0, out, Prelude.HEADER_LEN, payload.length);
        // remaining bytes (if any) are zero padding
        return out;
    }

    // Getters
    public MacAddress getDestination() { return destination; }
    public MacAddress getSource() { return source; }
    public short getEtherType() { return etherType; }
    public byte[] getPayload() { return Arrays.copyOf(payload, payload.length); }

    // Setters
    public void setDestination(MacAddress mac) {
        if (mac == null) throw new NullPointerException("mac");
        this.destination = mac;
    }
    
    public void setDestination(byte[] mac) {
	    if (mac == null) throw new NullPointerException("mac");
        if (mac.length != Prelude.MAC_ADDR_LEN) throw new IllegalArgumentException("MAC must be 6 bytes");
        this.destination = new MacAddress(mac);
    }

	public void setSource(MacAddress mac) {
	    if (mac == null) throw new NullPointerException("mac");
	    this.source = mac;
	}
	
	public void setSource(byte[] mac) {
	    if (mac.length != Prelude.MAC_ADDR_LEN) throw new IllegalArgumentException("MAC must be 6 bytes");
	    this.source = new MacAddress(mac);
	}

    public void setEtherType(short etherType) { this.etherType = etherType; }

    public void setPayload(byte[] payload) {
    	if (payload.length > Prelude.MAX_PAYLOAD_LEN) {
            throw new IllegalArgumentException("Payload too large (max " + Prelude.MAX_PAYLOAD_LEN + ")");
        }
        this.payload = Arrays.copyOf(payload, payload.length);
    }
}
