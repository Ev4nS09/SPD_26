package ethernet;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ DeviceFrameTest.class, DeviceTest.class, EthernetFrameTest.class, 
	MacAddressTest.class,
	SwitchTest.class })
public class AllTests {

}
