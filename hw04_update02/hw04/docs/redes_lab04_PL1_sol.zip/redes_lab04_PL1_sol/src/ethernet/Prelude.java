package ethernet;

// all public definitions
public class Prelude {
    protected static final int MAC_ADDR_LEN = 6;
    protected static final int HEADER_LEN = 14;
    protected static final int MIN_PAYLOAD_LEN = 46;
    protected static final int MAX_PAYLOAD_LEN = 1500;
    // 
    public static final MacAddress BROADCAST_ADDR =
        new MacAddress(new byte[]{(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF});
}
