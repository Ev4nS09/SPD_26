package ethernet;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.RepeatedTest;
import java.util.Random;

class EthernetFrameTest {
	private Random random;
	

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	    random = new Random();
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	private void testNullPointerException(Runnable action) {
	    assertThrows(NullPointerException.class, action::run);
	}

	@Test
	void testConstructorWithNullParameters() {
	    byte[] validMac = new byte[Prelude.MAC_ADDR_LEN];
	    byte[] payload = new byte[10];
	    short ethernetType = (short)0x0800; 

	    assertAll(
	        () -> testNullPointerException(() -> new EthernetFrame(null, validMac, ethernetType, payload)),
	        () -> testNullPointerException(() -> new EthernetFrame(validMac, null, ethernetType, payload)),
	        () -> testNullPointerException(() -> new EthernetFrame(validMac, validMac, ethernetType, null))
	    );
	    
	    assertAll(
	    		() -> testNullPointerException(() -> new EthernetFrame(null))
	    		);
	}
	
	@Test
	void testSettersWithNull() {
	    byte[] validMac = new byte[Prelude.MAC_ADDR_LEN];
	    byte[] payload = new byte[10];
	    short ethernetType = (short) 0x0800;

	    // a valid, normal frame to start with
	    EthernetFrame frame = new EthernetFrame(validMac, validMac, ethernetType, payload);


	    MacAddress null_mac_address = null; 
	    byte[] byte_null = null; 
	    
	    assertAll(
		        () -> testNullPointerException(() -> frame.setDestination(null_mac_address)),
		        () -> testNullPointerException(() -> frame.setDestination(byte_null)),
		        () -> testNullPointerException(() -> frame.setSource(null_mac_address)),
		        () -> testNullPointerException(() -> frame.setSource(byte_null)),
		        () -> testNullPointerException(() -> frame.setPayload(byte_null))
		    );
	}
	
	private void testIllegalAction(Runnable action) {
	    assertThrows(IllegalArgumentException.class, action::run);
	}
	
	@Test
	void testConstructorWithIllegalArguments() {
	    byte[] validMac = new byte[Prelude.MAC_ADDR_LEN];
	    byte[] payload = new byte[Prelude.MAX_PAYLOAD_LEN+1];
	    short ethernetType = (short)0x0800; 

	    testIllegalAction(() -> new EthernetFrame(validMac, validMac, ethernetType, payload));
	    
	    byte[] raw = new byte[1515];
	    testIllegalAction(() -> new EthernetFrame(raw));
	    
	    
	    
	    
	}
	
	@Test
	void testSerializationAndDeserializationAreConsistent() {
	    byte[] validMac = new byte[Prelude.MAC_ADDR_LEN];
        short etherType = (short)0x0800; 
        byte[] payload = "Hello".getBytes();

        EthernetFrame frame = new EthernetFrame(validMac, validMac, etherType, payload);
        byte[] raw = frame.toBytes();
        
        EthernetFrame frame2 = new EthernetFrame(raw);
        byte[] raw2 = frame2.toBytes();
        assertArrayEquals(raw, raw2);
	}
	
	@Test
	void constructorAcceptsEmptyAndMaxPayload() {
	    byte[] mac = new byte[Prelude.MAC_ADDR_LEN];
	    short etherType = (short) 0x0800;

	    assertDoesNotThrow(() -> new EthernetFrame(mac, mac, etherType, new byte[0]));

	    assertDoesNotThrow(() -> new EthernetFrame(mac, mac, etherType, new byte[Prelude.MAX_PAYLOAD_LEN]));
	}
	
	@Test
	void macLengthMustBeExactlySix() {
	    byte[] mac5 = new byte[5];
	    byte[] mac6 = new byte[6];
	    byte[] mac7 = new byte[7];
	    byte[] payload = new byte[10];
	    short etherType = (short) 0x0800;

	    assertThrows(IllegalArgumentException.class, () -> new EthernetFrame(mac5, mac6, etherType, payload));
	    assertThrows(IllegalArgumentException.class, () -> new EthernetFrame(mac6, mac7, etherType, payload));
	    assertDoesNotThrow(() -> new EthernetFrame(mac6, mac6, etherType, payload));
	}
	
	@Test
	void constructorDefensiveCopiesInputs() {
	    // Arrange: build arrays with known values
	    byte[] dest = new byte[]{1, 1, 1, 1, 1, 1};
	    byte[] src  = new byte[]{2, 2, 2, 2, 2, 2};
	    byte[] payload = new byte[]{3, 3, 3};
	    short etherType = (short) 0x0800;

	    // Act: construct the frame
	    EthernetFrame frame = new EthernetFrame(dest, src, etherType, payload);

	    // Mutate the original arrays AFTER construction
	    dest[0] = 9;
	    src[0] = 9;
	    payload[0] = 9;

	    // Assert: serialised frame still reflects the original values,
	    // not the mutated ones
	    byte[] raw = frame.toBytes();

	    // Destination starts at offset 0
	    assertEquals(1, raw[0]);
	    // Source starts at offset 6
	    assertEquals(2, raw[6]);
	    // Payload starts at offset 14 (6 dest + 6 src + 2 etherType)
	    assertEquals(3, raw[14]);
	}
	
	
	@Test
	void toBytesReturnsDefensiveCopy() {
	    byte[] mac = new byte[Prelude.MAC_ADDR_LEN];
	    byte[] payload = new byte[]{1,2,3};
	    short etherType = (short) 0x0800;
	
	    EthernetFrame frame = new EthernetFrame(mac, mac, etherType, payload);
	
	    byte[] raw1 = frame.toBytes();
	    raw1[0] = 99; // try to corrupt
	
	    byte[] raw2 = frame.toBytes();
	    assertNotEquals(99, raw2[0], "toBytes should return a fresh copy");
	}
	
	@Test
	void fromBytesConstructorValidatesLength() {
	    // too short 
	    assertThrows(IllegalArgumentException.class, () -> new EthernetFrame(new byte[13]));
	}
	
	@Test
	void layoutAndEndiannessAreCorrect() {
	    byte[] dest = new byte[]{0,1,2,3,4,5};
	    byte[] src  = new byte[]{6,7,8,9,10,11};
	    short etherType = (short) 0x0800;       // IPv4
	    byte[] payload = new byte[]{12,13};
	
	    EthernetFrame frame = new EthernetFrame(dest, src, etherType, payload);
	    byte[] raw = frame.toBytes();
	
	    // destination 0..5
	    assertArrayEquals(dest, java.util.Arrays.copyOfRange(raw, 0, 6));
	    // source 6..11
	    assertArrayEquals(src, java.util.Arrays.copyOfRange(raw, 6, 12));
	    // etherType big-endian at 12..13
	    assertEquals((byte)0x08, raw[12]);
	    assertEquals((byte)0x00, raw[13]);
	    // payload 14..
	    assertArrayEquals(payload, java.util.Arrays.copyOfRange(raw, 14, 16));
	}

	@Test
	void settersDefensiveCopyByteArrayOverloads() {
	    // Only if you have setters that take byte[] (e.g., setDestination(byte[]), setSource(byte[]), setPayload(byte[]))
	    byte[] mac = new byte[Prelude.MAC_ADDR_LEN];
	    EthernetFrame frame = new EthernetFrame(mac, mac, (short)0x0800, new byte[]{1,2,3});
	
	    byte[] newDest = new byte[]{10,11,12,13,14,15};
	    frame.setDestination(newDest);
	    newDest[0] = 99; // mutate after setting
	
	    byte[] raw = frame.toBytes();
	    assertEquals(10, raw[0], "Setter should copy input, not retain reference");
	}

	@Test
	void fromBytesAndToBytesAreSymmetric() {
	    byte[] dest = new byte[]{1,2,3,4,5,6};
	    byte[] src  = new byte[]{7,8,9,10,11,12};
	    short etherType = (short) 0x86DD; // IPv6
	    byte[] payload = new byte[32];
	
	    byte[] raw1 = new EthernetFrame(dest, src, etherType, payload).toBytes();
	    byte[] raw2 = new EthernetFrame(raw1).toBytes();
	
	    assertArrayEquals(raw1, raw2);
	}

    
    @RepeatedTest(10) // run several times with different random lengths
    void fromBytesConstructorRejectsFramesShorterThan60() {
        // Generate a random length between 0 (inclusive) and 60 (exclusive)
        int length = random.nextInt(60);

        byte[] raw = new byte[length];

        assertThrows(IllegalArgumentException.class,
            () -> new EthernetFrame(raw),
            "Expected exception for raw length = " + length);
    }

}
