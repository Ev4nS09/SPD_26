package ethernet;

import java.util.HashMap;

public class Switch {
    private HashMap<MacAddress,Port> forwarding_table = new HashMap<>(); // MAC-address x Port
    private HashMap<String,Port> ports = new HashMap<String,Port>(); // connected ports
	
    // it adds an entry to the switch (it adds a device plus its address)
    public void learn_entry(MacAddress address, Port client) {
    	forwarding_table.put(address,client);
    }
    
    // device connected to inPort sends a frame, for instance
    // after the switch floods all the ports, the port calls method "receive" with
    // appropriate parameters
    public void receive(EthernetFrame frame, Port inPort) {
    	if (frame == null || inPort == null)
            throw new NullPointerException();
    	
    	if (frame.getDestination().equals(Prelude.BROADCAST_ADDR)) {
    	    flooding(frame, inPort);
    	    return;
    	}
    	
    	learn_entry(frame.getSource(),inPort); // learning on-the-fly
    	
    	// forward to frame to the correct port
    	Port outPort = forwarding_table.get(frame.getDestination());
    	if (outPort == null) 
    		flooding(frame,inPort);
    	else 
    		if (outPort != inPort)
    			outPort.send(frame);
    }
    
    // flooding frame to all ports except inPort
    public void flooding(EthernetFrame frame, Port inPort) {
    	if (frame == null || inPort == null)
            throw new NullPointerException();
    	
    	for(Port port : ports.values()) {
    		if (port != inPort) {
    			port.send(frame);
    		}
    	}
    }
    
    // setters
    public void addPort(String id, Port port) {
        if (id == null || port == null) throw new NullPointerException();
        if (ports.containsKey(id)) {
            throw new IllegalArgumentException("Port ID already exists: " + id);
        }
        ports.put(id, port);
    }
    
    public void removePort(String id) {
        Port removed = ports.remove(id);
        if (removed == null) return;

        // Optional: clean forwarding entries that pointed to this port
        forwarding_table.entrySet().removeIf(e -> e.getValue() == removed);
    }
    
    
    // getters
    public Port getPort(String id) {
        if (id == null) throw new NullPointerException();
    	return ports.get(id);
    }
    
    public boolean containsPort(String id) {
        if (id == null) throw new NullPointerException();
        return ports.containsKey(id);
    }
    
    public java.util.Set<String> getPortIds() {
        return java.util.Collections.unmodifiableSet(ports.keySet());
    }
}
