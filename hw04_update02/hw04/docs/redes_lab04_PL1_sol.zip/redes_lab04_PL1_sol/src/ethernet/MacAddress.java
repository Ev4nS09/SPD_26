package ethernet;

public class MacAddress {
	private final byte[] address;

    public MacAddress(byte[] address) {
        if (address.length != Prelude.MAC_ADDR_LEN) {
            throw new IllegalArgumentException("MAC addresses must be 6 bytes");
        }
        this.address = address.clone(); // defensive copy
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MacAddress)) return false;
        MacAddress that = (MacAddress) o;
        return java.util.Arrays.equals(this.address, that.address);
    }

	@Override
	public int hashCode() {
	    return java.util.Arrays.hashCode(address);
	}
    
    public byte[] getBytes() {
        return address.clone();
    }
    
    // it return a MacAddress object from a String representation, e.g., "AA:BB:CC:DD:EE:FF"
    public static MacAddress fromString(String mac) {
        String[] parts = mac.toUpperCase().split(":");
        
        if (parts.length != Prelude.MAC_ADDR_LEN) {
            throw new IllegalArgumentException("Invalid MAC string: " + mac);
        }
        byte[] bytes = new byte[Prelude.MAC_ADDR_LEN];
        for (int i = 0; i < parts.length; i++) {
            if (!parts[i].matches("[0-9A-Fa-f]{2}")) {
                throw new IllegalArgumentException("Invalid hex byte: " + parts[i]);
            }
            
            bytes[i] = (byte) Integer.parseInt(parts[i], 16);
        }
        return new MacAddress(bytes);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < address.length; i++) {
            sb.append(String.format("%02X", address[i]));
            if (i < address.length - 1) {
                sb.append(":");
            }
        }
        return sb.toString();
    }

}
