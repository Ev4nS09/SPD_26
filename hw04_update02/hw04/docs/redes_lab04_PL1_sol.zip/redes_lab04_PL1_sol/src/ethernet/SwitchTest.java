package ethernet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class SwitchTest {

    private static final short ETHERTYPE_IPV4 = (short) 0x0800;

    private Switch sw;
    private TestPort portA, portB, portC;
    private MacAddress macA, macB, macC;

    @BeforeEach
    void setup() {
        sw = new Switch();

        macA = MacAddress.fromString("00:00:00:00:00:0A");
        macB = MacAddress.fromString("00:00:00:00:00:0B");
        macC = MacAddress.fromString("00:00:00:00:00:0C");

        // A: no auto-reply (to avoid ping-pong).
        portA = new TestPort("A", macA, sw, false);
        // B: we can flip autoReply on in specific tests
        portB = new TestPort("B", macB, sw, false);
        // C: a third port to observe flooding behaviour
        portC = new TestPort("C", macC, sw, false);

        sw.addPort("A", portA);
        sw.addPort("B", portB);
        sw.addPort("C", portC);

        // sanity
        assertTrue(sw.containsPort("A"));
        assertTrue(sw.containsPort("B"));
        assertTrue(sw.containsPort("C"));
    }

    // Helper to build a valid Ethernet frame per your model (46..1500 payload).
    private EthernetFrame frameTo(MacAddress dst, MacAddress src) {
        byte[] payload = new byte[Prelude.MIN_PAYLOAD_LEN]; // min-length payload
        return new EthernetFrame(dst.getBytes(), src.getBytes(), ETHERTYPE_IPV4, payload);
    }

    // ---------- 1) Learning: if A sends to B, then A is learned ----------
    @Test
    void learningOccursOnIngressSource() {
        // A sends unknown-unicast to B
        sw.receive(frameTo(macB, macA), portA);

        // Clear any flooded deliveries from the first frame (to measure only the next step)
        portA.clear(); portB.clear(); portC.clear();

        // Now send a frame to A from C; since A was learned on Port A, this must unicast to A only.
        sw.receive(frameTo(macA, macC), portC);

        assertEquals(1, portA.receivedCount(), "Unicast should go to A");
        assertEquals(0, portB.receivedCount(), "No delivery to B");
        assertEquals(0, portC.receivedCount(), "Never echo back to ingress");
    }

    // ---------- 2) Unknown unicast floods (B receives the message) ----------
    @Test
    void unknownUnicastFloodsToAllExceptIngress_andBReceives() {
        // A sends to B (B not in table yet): should flood to B and C, not A
        sw.receive(frameTo(macB, macA), portA);

        assertEquals(0, portA.receivedCount(), "Ingress must not receive on flood");
        assertEquals(1, portB.receivedCount(), "B should receive the flooded frame");
        assertEquals(1, portC.receivedCount(), "Other ports should receive the flooded frame");
    }

    // ---------- 3) Unknown unicast does NOT send back to A (ingress excluded) ----------
    @Test
    void unknownUnicastDoesNotEchoToIngress() {
        sw.receive(frameTo(macB, macA), portA);
        assertEquals(0, portA.receivedCount(), "Flooding must exclude ingress (no echo to A)");
    }

    // ---------- 4) If B replies, the reply is unicast back to A ----------
    @Test
    void replyFromBDeliveredBackToA() {
        // Configure B to auto-reply when it receives a frame addressed to its MAC.
        portB.setAutoReply(true);

        // Step 1: A sends to B (unknown → flood). B receives and auto-replies (dst=A, src=B).
        sw.receive(frameTo(macB, macA), portA);

        // After auto-reply, switch should have learned both A and B and unicast B's reply to A.
        // A must have received at least one frame from B.
        assertTrue(portA.receivedCount() >= 1, "A should receive B's reply");
        EthernetFrame lastForA = portA.lastReceived();
        assertEquals(macA, lastForA.getDestination(), "Reply destination should be A");
        assertEquals(macB, lastForA.getSource(), "Reply source should be B");
    }

    // ---------- 5) Ports keys are not repeated (duplicate ID throws) ----------
    @Test
    void duplicatePortIdsAreRejected() {
        TestPort anotherA = new TestPort("A2", macA, sw, false);
        assertThrows(IllegalArgumentException.class, () -> sw.addPort("A", anotherA));
    }

    // ---------- 6) NullPointerException for relevant methods ----------
    @Test
    void nullPointerGuards() {
        // addPort null args
        assertThrows(NullPointerException.class, () -> sw.addPort(null, portA));
        assertThrows(NullPointerException.class, () -> sw.addPort("Z", null));

        // getPort/containsPort null ids
        assertThrows(NullPointerException.class, () -> sw.getPort(null));
        assertThrows(NullPointerException.class, () -> sw.containsPort(null));

        // receive null args
        EthernetFrame valid = frameTo(macB, macA);
        assertThrows(NullPointerException.class, () -> sw.receive(null, portA));
        assertThrows(NullPointerException.class, () -> sw.receive(valid, null));

        // flooding null args
        assertThrows(NullPointerException.class, () -> sw.flooding(null, portA));
        assertThrows(NullPointerException.class, () -> sw.flooding(valid, null));
    }

    // ---------- 7) IllegalArgumentException for relevant methods (duplicate port id) ----------
    @Test
    void illegalArgumentOnDuplicatePortId() {
        TestPort d = new TestPort("D", MacAddress.fromString("00:00:00:00:00:0D"), sw, false);
        sw.addPort("D", d);
        assertThrows(IllegalArgumentException.class, () -> sw.addPort("D", new TestPort("D2",
                MacAddress.fromString("00:00:00:00:00:EE"), sw, false)));
    }
    
    
	// ---------- 8) If A sends to B and B is not in the table,
	// then B does not receive it as unicast but as broadcast (flood).
    @Test
    void unknownUnicastDeliveredToBByFloodNotUnicast() {
        // A sends to B (B not yet learned) → should FLOOD to all except ingress (A)
        sw.receive(frameTo(macB, macA), portA);

        // Flood pattern: B and C each get one copy; A (ingress) gets none
        assertEquals(0, portA.receivedCount(), "Ingress must not receive on flood");
        assertEquals(1, portB.receivedCount(), "B should receive the flooded (not unicast) frame");
        assertEquals(1, portC.receivedCount(), "Another egress port should also receive the flooded frame");

        // (Optional sanity) The frame seen by B is the original A→B
        EthernetFrame forB = portB.lastReceived();
        assertEquals(macB, forB.getDestination());
        assertEquals(macA, forB.getSource());
    }
    
    // ===== Test double for Port =====
    private static class TestPort implements Port {
        private final String id;
        private final MacAddress mac;
        private final Switch sw;
        private boolean autoReply;
        private final List<EthernetFrame> received = new ArrayList<>();

        TestPort(String id, MacAddress mac, Switch sw, boolean autoReply) {
            this.id = id;
            this.mac = mac;
            this.sw = sw;
            this.autoReply = autoReply;
        }

        @Override
        public String get_Id() {
            return id;
        }

        @Override
        public void send(EthernetFrame frame) {
            // Record received frame
            received.add(frame);

            // Optional behaviour for tests: if configured, reply to frames addressed to this MAC
            if (autoReply && mac.equals(frame.getDestination())) {
                byte[] payload = new byte[Prelude.MIN_PAYLOAD_LEN];
                EthernetFrame reply = new EthernetFrame(
                        frame.getSource().getBytes(),   // reply to original sender
                        mac.getBytes(),                 // from this device
                        ETHERTYPE_IPV4,
                        payload
                );
                // Send reply back into the switch via THIS port
                sw.receive(reply, this);
            }
        }

        // Helpers for assertions
        int receivedCount() { return received.size(); }
        EthernetFrame lastReceived() { return received.isEmpty() ? null : received.get(received.size() - 1); }
        void clear() { received.clear(); }
        void setAutoReply(boolean v) { this.autoReply = v; }
    }
}
