package ethernet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DeviceTest {
	
    private final MacAddress dummyMac = MacAddress.fromString("00:00:00:00:00:01");
    private final Switch dummySwitch = new Switch();
    

    private static final short ETHERTYPE_IPV4 = (short) 0x0800;

    private SpySwitch parent;
    private MacAddress senderMac;
    private MacAddress deviceMac;
    private Device device;


	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
        parent = new SpySwitch();
        senderMac = MacAddress.fromString("00:00:00:00:00:AA");
        deviceMac = MacAddress.fromString("00:00:00:00:00:01");
        device = new Device("dev-1", deviceMac, parent);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	private void testNullPointerException(Runnable action) {
	    assertThrows(NullPointerException.class, action::run);
	}


    private EthernetFrame frame(MacAddress dst, MacAddress src) {
        byte[] payload = new byte[Prelude.MIN_PAYLOAD_LEN];
        return new EthernetFrame(dst.getBytes(), src.getBytes(), ETHERTYPE_IPV4, payload);
    }

	@Test
	void testConstructorWithNullParameters() {
	    assertAll(
	        () -> testNullPointerException(() -> new Device(null, dummyMac, dummySwitch)),
	        () -> testNullPointerException(() -> new Device("dev-1", null, dummySwitch)),
	        () -> testNullPointerException(() -> new Device("dev-1", dummyMac, null))
	    );
	    
	}
	
	
	@Test
    void constructorSucceedsWithValidParameters() {
        Device device = new Device("dev-1", dummyMac, dummySwitch);
        assertNotNull(device);
        assertEquals("dev-1", device.get_Id());
        assertEquals(dummyMac, device.get_Mac());
        assertSame(dummySwitch, device.get_Parent());
    }

	@Test
	void testSettersWithNull() {
	    
	    assertAll(
		        () -> testNullPointerException(() -> device.set_Id(null))
		    );
	}

    @Test
    void setId_thenGetIdReturnsSameValue() {
        String newId = "dev-42";
        device.set_Id(newId);
        assertEquals(newId, device.get_Id(), "get_Id should return the id set with set_Id");
    }

    /**
     * 1) If destination is broadcast, Device must call parent.receive(...)
     *    and the frame it communicates must carry the device's MAC as source.
     */
    @Test
    void send_callsParentReceiveOnBroadcast_andUsesDeviceMacAsSource() {
        EthernetFrame incoming = frame(Prelude.BROADCAST_ADDR, senderMac);

        device.send(incoming);

        assertEquals(1, parent.calls, "parent.receive should be called exactly once");
        assertNotNull(parent.lastFrame, "parent should receive a frame");
        assertSame(device, parent.lastPort, "device should be the inPort used");
        assertEquals(deviceMac, parent.lastFrame.getSource(),
                "frame sent to parent must use the device MAC as source");
    }

    /**
     * 2) If destination is NOT broadcast, Device must NOT call parent.receive(...).
     */
    @Test
    void send_doesNotCallParentReceiveOnUnicast() {
        MacAddress otherDst = MacAddress.fromString("00:00:00:00:00:02");
        EthernetFrame incoming = frame(otherDst, senderMac);

        device.send(incoming);

        assertEquals(0, parent.calls, "parent.receive should not be called");
        assertNull(parent.lastFrame);
        assertNull(parent.lastPort);
    }
	

    /**
     * Minimal spy switch that just records receive(...) calls.
     */
    private static class SpySwitch extends Switch {
        int calls = 0;
        EthernetFrame lastFrame = null;
        Port lastPort = null;

        @Override
        public void receive(EthernetFrame frame, Port inPort) {
            calls++;
            lastFrame = frame;
            lastPort = inPort;
        }
    }

}
