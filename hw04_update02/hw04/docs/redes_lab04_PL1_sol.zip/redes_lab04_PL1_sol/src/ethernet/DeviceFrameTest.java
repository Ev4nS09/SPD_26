package ethernet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Device (broadcast reply behavior).
 */
class DeviceFrameTest {

    private static final short ETHERTYPE_IPV4 = (short) 0x0800;

    private TestSwitch sw;
    private MacAddress senderMac;
    private MacAddress deviceMac;
    private Device device;

    @BeforeEach
    void setup() {
        sw = new TestSwitch();
        senderMac = MacAddress.fromString("00:00:00:00:00:AA");
        deviceMac = MacAddress.fromString("00:00:00:00:00:01");
        device = new Device("dev-1", deviceMac, sw);
    }

    // Helper: build a valid Ethernet frame (min-size payload per your model)
    private EthernetFrame frame(MacAddress dst, MacAddress src) {
        byte[] payload = new byte[Prelude.MIN_PAYLOAD_LEN];
        return new EthernetFrame(dst.getBytes(), src.getBytes(), ETHERTYPE_IPV4, payload);
    }

    // 1) Broadcast to device → device sends a reply via parent switch
    @Test
    void broadcastToDeviceTriggersReplyViaSwitch() {
        // The switch "sends" a broadcast frame to the device
        EthernetFrame incoming = frame(Prelude.BROADCAST_ADDR, senderMac);

        device.send(incoming);

        assertEquals(1, sw.recvCount, "Device should inject exactly one reply via the switch");
        assertNotNull(sw.lastFrame, "Switch should have received a reply frame");
        assertSame(device, sw.lastInPort, "Reply should be injected from the device's own port");

        // Validate reply addressing
        assertEquals(senderMac, sw.lastFrame.getDestination(), "Reply should go back to original sender");
        assertEquals(deviceMac, sw.lastFrame.getSource(), "Reply source must be the device's MAC");

        // Validate EtherType big-endian (0x0800) and payload length = MIN_PAYLOAD_LEN
        byte[] raw = sw.lastFrame.toBytes();
        assertEquals(Prelude.HEADER_LEN + Prelude.MIN_PAYLOAD_LEN, raw.length, "Reply total length must be header + min payload");
        assertEquals((byte) 0x08, raw[12], "EtherType high byte must be 0x08");
        assertEquals((byte) 0x00, raw[13], "EtherType low byte must be 0x00");
    }

    // 2) Unicast to this device → no automatic reply
    @Test
    void unicastToDeviceDoesNotTriggerReply() {
        EthernetFrame incoming = frame(deviceMac, senderMac); // dst = this device
        device.send(incoming);
        assertEquals(0, sw.recvCount, "Device should NOT auto-reply to unicast frames");
        assertNull(sw.lastFrame);
        assertNull(sw.lastInPort);
    }

    // 3) Unicast to some other MAC → no reply (device ignores frames not addressed to broadcast)
    @Test
    void unicastToOtherMacDoesNotTriggerReply() {
        MacAddress otherDst = MacAddress.fromString("00:00:00:00:00:02");
        EthernetFrame incoming = frame(otherDst, senderMac);
        device.send(incoming);
        assertEquals(0, sw.recvCount);
        assertNull(sw.lastFrame);
    }

    // 4) Getter sanity (no side effects, values carried through)
    @Test
    void gettersReturnConstructorValues() {
        assertEquals("dev-1", device.get_Id());
        assertEquals(deviceMac, device.get_Mac());
        assertSame(sw, device.get_Parent());
    }

    /**
     * Minimal test double for Switch that records what Device sends back.
     */
    private static class TestSwitch extends Switch {
        int recvCount = 0;
        EthernetFrame lastFrame = null;
        Port lastInPort = null;

        @Override
        public void receive(EthernetFrame frame, Port inPort) {
            recvCount++;
            lastFrame = frame;
            lastInPort = inPort;
            // Do NOT forward anywhere; we just record that Device injected a reply.
        }
    }
}
