package ethernet;

public interface Port {
	public abstract String get_Id(); // deliver frame out of this port
	public abstract void send(EthernetFrame frame); // deliver frame out of this port
}
