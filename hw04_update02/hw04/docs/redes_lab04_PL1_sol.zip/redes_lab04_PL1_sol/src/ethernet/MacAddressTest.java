package ethernet;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MacAddressTest {

    // Helper: a valid MAC address as bytes
    private final byte[] validBytes = new byte[] {0x00, 0x11, 0x22, 0x33, 0x44, 0x55};
    private final String validString = "00:11:22:33:44:55";

    /**
     * 1. Check non-nullness of parameters for constructors and setters.
     *    (There are no setters in MacAddress, only the constructor.)
     */
    @Test
    void constructor_nullArrayThrowsException() {
        assertThrows(NullPointerException.class, () -> new MacAddress(null));
    }

    @Test
    void constructor_wrongLengthThrowsException() {
        // too short
        assertThrows(IllegalArgumentException.class, () -> new MacAddress(new byte[]{0x01, 0x02}));
        // too long
        assertThrows(IllegalArgumentException.class, () -> new MacAddress(new byte[10]));
    }

    /**
     * 2. For every setter and field: test that what you set you can get.
     *    (Here: constructor sets the address, and getBytes() returns it.)
     */
    @Test
    void getBytes_returnsCopyOfConstructorValue() {
        MacAddress mac = new MacAddress(validBytes);
        assertArrayEquals(validBytes, mac.getBytes(), "getBytes should return the same content as constructor input");
    }

    /**
     * 3. Check invariant that address is never null.
     */
    @Test
    void invariant_addressNeverNull() {
        MacAddress mac = new MacAddress(validBytes);
        assertNotNull(mac.getBytes(), "address must never be null");
    }

    /**
     * 4. fromString(str) → mac → toString() returns same str.
     */
    @Test
    void fromString_thenToStringReturnsSameString() {
        MacAddress mac = MacAddress.fromString(validString);
        assertEquals(validString.toUpperCase(), mac.toString(), "toString must reproduce the original input string");
    }

    @Test
    void fromString_invalidFormatThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> MacAddress.fromString("invalid"));
        assertThrows(IllegalArgumentException.class, () -> MacAddress.fromString("00:11:22:33:44")); // too short
        assertThrows(IllegalArgumentException.class, () -> MacAddress.fromString("00:11:22:33:44:ZZ")); // bad hex
    }

    /**
     * 5. Constructor must defensively clone array; modifying caller array should not affect MacAddress.
     */
    @Test
    void constructorClonesArrayAndProtectsInternalState() {
        byte[] bytes = validBytes.clone();
        MacAddress mac = new MacAddress(bytes);

        // Change the original array
        bytes[0] = (byte) 0x7F;

        // The internal state must remain unchanged
        assertEquals(validString, mac.toString(), "Internal state must not change when original array is mutated");

        // Also, getBytes() must return a copy, not the internal array
        byte[] returned = mac.getBytes();
        returned[1] = (byte) 0x7F;
        assertEquals(validString, mac.toString(), "Internal state must not change when returned array is mutated");
    }
}
